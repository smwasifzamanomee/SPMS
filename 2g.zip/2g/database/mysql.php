<?php
    $mysql = new mysqli('localhost', 'root', '', 'spm-iub');
?>
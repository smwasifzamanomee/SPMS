<?php
	require '../database/mysql.php';
	$sql = "SELECT * FROM student";
	$students = $mysql->query($sql)->num_rows;
	$sql = "SELECT * FROM school";
	$schools = $mysql->query($sql)->num_rows;
	$sql = "SELECT * FROM department";
	$departments = $mysql->query($sql)->num_rows;
	$sql = "SELECT * FROM program";
	$programs = $mysql->query($sql)->num_rows;

	if(isset($_GET['semester'])){
		$semester = $_GET['semester'];
		$sql = "SELECT school.school_name, COUNT(DISTINCT(enrollment.student_id)) as 'students' FROM school NATURAL LEFT JOIN department NATURAL LEFT JOIN program NATURAL LEFT JOIN section NATURAL LEFT JOIN enrollment 
		WHERE section.semester = '$semester' GROUP BY school.school_name";
		$school = $mysql->query($sql);

		$sql = "SELECT department.department_id, COUNT(DISTINCT(enrollment.student_id)) as 'students' FROM department NATURAL LEFT JOIN program NATURAL LEFT JOIN section NATURAL LEFT JOIN enrollment 
		WHERE section.semester = '$semester' GROUP BY department.department_id";
		$department = $mysql->query($sql);

		$sql = "SELECT program.program_name, program.department_id, COUNT(DISTINCT(enrollment.student_id)) as 'students' FROM program NATURAL LEFT JOIN section NATURAL LEFT JOIN enrollment 
		WHERE section.semester = '$semester' GROUP BY program.program_id";
		$program = $mysql->query($sql);
	}

?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">

	<link rel="shortcut icon" href="img/icons/icon-48x48.png" />

	<title>Dashboard - SPMS</title>

	<link href="../css/app.css" rel="stylesheet">
</head>

<body>
	<div class="wrapper">
		<nav id="sidebar" class="sidebar">
			<div class="sidebar-content js-simplebar">
				<a class="sidebar-brand" href="index.php">
					<span class="align-middle">SPM</span>
				</a>

				<ul class="sidebar-nav">
					
					<li class="sidebar-item active">
						<a class="sidebar-link" href="index.php">
						<i class="align-middle" data-feather="sliders"></i> <span class="align-middle">Dashboard</span>
						</a>
					</li>

					<li class="sidebar-item">
						<a class="sidebar-link" href="universities.php">
							<i class="align-middle" data-feather="home"></i> <span class="align-middle">Universities</span>
						</a>
					</li>

					<li class="sidebar-item">
						<a class="sidebar-link" href="university-create.php">
							<i class="align-middle" data-feather="plus-square"></i> <span class="align-middle">University Create</span>
						</a>
					</li>

					<li class="sidebar-item">
						<a class="sidebar-link" href="users.php">
							<i class="align-middle" data-feather="user"></i> <span class="align-middle">Users</span>
						</a>
					</li>

					<li class="sidebar-item">
						<a class="sidebar-link" href="user-create.php">
							<i class="align-middle" data-feather="user-plus"></i> <span class="align-middle">Create User</span>
						</a>
					</li>

					<li class="sidebar-item">
						<a class="sidebar-link" href="schools.php">
							<i class="align-middle" data-feather="server"></i> <span class="align-middle">Schools</span>
						</a>
					</li>

					<li class="sidebar-item">
						<a class="sidebar-link" href="school-create.php">
							<i class="align-middle" data-feather="plus"></i> <span class="align-middle">Create School</span>
						</a>
					</li>

					<li class="sidebar-item">
						<a class="sidebar-link" href="departments.php">
							<i class="align-middle" data-feather="briefcase"></i> <span class="align-middle">Departments</span>
						</a>
					</li>

					<li class="sidebar-item">
						<a class="sidebar-link" href="department-create.php">
							<i class="align-middle" data-feather="plus-circle"></i> <span class="align-middle">Create Department</span>
						</a>
					</li>

					<li class="sidebar-item">
						<a class="sidebar-link" href="programs.php">
							<i class="align-middle" data-feather="folder"></i> <span class="align-middle">Programs</span>
						</a>
					</li>


					<li class="sidebar-item">
						<a class="sidebar-link" href="program-create.php">
							<i class="align-middle" data-feather="folder-plus"></i> <span class="align-middle">Create Programs</span>
						</a>
					</li>

					<li class="sidebar-item">
						<a class="sidebar-link" href="courses.php">
							<i class="align-middle" data-feather="file"></i> <span class="align-middle">Courses</span>
						</a>
					</li>

					<li class="sidebar-item">
						<a class="sidebar-link" href="course-create.php">
							<i class="align-middle" data-feather="file-plus"></i> <span class="align-middle">Create Courses</span>
						</a>
					</li>

					<li class="sidebar-item">
						<li class="sidebar-item">
						<a class="sidebar-link" href="../login.php?logout=1">
							<i class="align-middle" data-feather="log-out"></i> <span class="align-middle">LogOut</span>
						</a>
					</li>
					</li>
				</ul>
			</div>
		</nav>

		<div class="main">
			<nav class="navbar navbar-expand navbar-light navbar-bg">
				<a class="sidebar-toggle d-flex">
					<i class="hamburger align-self-center"></i>
				</a>

			</nav>

			<main class="content">
				<div class="container-fluid p-0">

					<h1 class="h3 mb-3">Dashboard</h1>

					<div class="row">
						<div class="col-sm-3">
							<div class="card">
								<div class="card-body">
									<h5 class="card-title mb-4">Total Students</h5>
									<h1 class="display-5 mt-1 mb-3"><?php echo $students; ?></h1>
								</div>
							</div>
						</div>
						<div class="col-sm-3">
							<div class="card">
								<div class="card-body">
									<h5 class="card-title mb-4">Total Schools</h5>

									<h1 class="display-5 mt-1 mb-3"><?php echo $schools; ?></h1>
								</div>
							</div>
						</div>
						<div class="col-sm-3">
							<div class="card">
								<div class="card-body">
									<h5 class="card-title mb-4">Total Departments</h5>
									<h1 class="display-5 mt-1 mb-3"><?php echo $departments; ?></h1>
								</div>
							</div>
						</div>
						<div class="col-sm-3">
							<div class="card">
								<div class="card-body">
									<h5 class="card-title mb-4">Total Programs</h5>
									<h1 class="display-5 mt-1 mb-3"><?php echo $programs; ?></h1>
								</div>
							</div>
						</div>
					</div>

					<div class="row">
						<div class="col-8">
							<h1 class="h3 mb-3">Enrollment Comparison</h1>
						</div>
						<div class="col-4 d-flex justify-content-end">
							<form class="form-inline" method="GET">
									<input type="text" class="form-control" id="semester" name="semester" placeholder="Summer-2021">
									<button type="submit" class="btn btn-primary ml-2"><i class="align-middle" data-feather="arrow-right"></i></button>
							</form>
						</div>
					</div>

					<div class="row mt-2">
						<div class="col-4">
							<div class="card">
								<div class="card-header">
									<h5 class="card-title">School Wise Enrollment Comparision</h5>
									<!-- <h6 class="card-subtitle text-muted">A bar chart provides a way of showing data values represented as vertical bars.</h6> -->
								</div>
								<div class="card-body text-center">
									<?php
										if(isset($semester)){
											echo '
											<div class="chart">
												<canvas id="bar-school"></canvas>
											</div>';
										}else{
											echo '<small class="text-secondary mt-5">Semester not selected or not found!</small>';
										}
									?>
								</div>
							</div>
						</div>
						<div class="col-4">
							<div class="card">
								<div class="card-header">
									<h5 class="card-title">Department Wise Enrollment Comparision</h5>
									<!-- <h6 class="card-subtitle text-muted">A bar chart provides a way of showing data values represented as vertical bars.</h6> -->
								</div>
								<div class="card-body text-center">
									<?php
										if(isset($semester)){
											echo '
											<div class="chart">
												<canvas id="bar-department" height="200" width="400"></canvas>
											</div>';
										}else{
											echo '<small class="text-secondary mt-5">Semester not selected or not found!</small>';
										}
									?>
									
								</div>
							</div>
						</div>
						<div class="col-4">
							<div class="card">
								<div class="card-header">
									<h5 class="card-title">Program Wise Enrollment Comparision</h5>
									<!-- <h6 class="card-subtitle text-muted">A bar chart provides a way of showing data values represented as vertical bars.</h6> -->
								</div>
								<div class="card-body text-center">
									<?php
										if(isset($semester)){
											echo '
											<div class="chart">
												<canvas id="bar-program" height="200" width="400"></canvas>
											</div>';
										}else{
											echo '<small class="text-secondary mt-5">Semester not selected or not found!</small>';
										}
									?>
									
								</div>
							</div>
						</div>
					</div>

				</div>
			</main>

			<footer class="footer">
				<div class="container-fluid">
					<div class="row text-muted">
						<div class="col-6 text-left">
							<p class="mb-0">
								<a href="index.php" class="text-muted"><strong>AdminKit Demo</strong></a> &copy;
							</p>
						</div>
						<div class="col-6 text-right">
							<ul class="list-inline">
								<li class="list-inline-item">
									<a class="text-muted" href="#">Support</a>
								</li>
								<li class="list-inline-item">
									<a class="text-muted" href="#">Help Center</a>
								</li>
								<li class="list-inline-item">
									<a class="text-muted" href="#">Privacy</a>
								</li>
								<li class="list-inline-item">
									<a class="text-muted" href="#">Terms</a>
								</li>
							</ul>
						</div>
					</div>
				</div>
			</footer>
		</div>
	</div>

	<script src="../js/vendor.js"></script>
	<script src="../js/app.js"></script>

	<script>
		$(function() {
			// Bar chart
			new Chart(document.getElementById("bar-school"), {
				type: "bar",
				data: {
					labels: [
						<?php
							if(isset($semester)){
								foreach($school as $scl){
									echo "'".$scl['school_name']."', ";
								}
							}
						?>
					],
					datasets: [{
						label: "Enrolled",
						backgroundColor: window.theme.primary,
						borderColor: window.theme.primary,
						hoverBackgroundColor: window.theme.primary,
						hoverBorderColor: window.theme.primary,
						data: [
							<?php
							if(isset($semester)){
								foreach($school as $scl){
									echo "".$scl['students'].", ";
								}
							}
						?>
						],
						barPercentage: .80,
						categoryPercentage: .5
					}]
				},
				options: {
					maintainAspectRatio: false,
					legend: {
						display: false
					},
					scales: {
						yAxes: [{
							gridLines: {
								display: false
							},
							stacked: false,
							ticks: {
								stepSize: 10
							}
						}],
						xAxes: [{
							stacked: false,
							gridLines: {
								color: "transparent"
							}
						}]
					}
				}
			});
		});
	</script>

	<script>
		$(function() {
			// Bar chart
			new Chart(document.getElementById("bar-department"), {
				type: "bar",
				data: {
					labels: [
						<?php
							if(isset($semester)){
								foreach($department as $dpt){
									echo "'".$dpt['department_id']."', ";
								}
							}
						?>
					],
					datasets: [{
						label: "Enrolled",
						backgroundColor: window.theme.primary,
						borderColor: window.theme.primary,
						hoverBackgroundColor: window.theme.primary,
						hoverBorderColor: window.theme.primary,
						data: [
							<?php
							if(isset($semester)){
								foreach($department as $dpt){
									echo "".$dpt['students'].", ";
								}
							}
						?>
						],
						barPercentage: .80,
						categoryPercentage: .5
					}]
				},
				options: {
					maintainAspectRatio: false,
					legend: {
						display: false
					},
					scales: {
						yAxes: [{
							gridLines: {
								display: false
							},
							stacked: false,
							ticks: {
								stepSize: 10
							}
						}],
						xAxes: [{
							stacked: false,
							gridLines: {
								color: "transparent"
							}
						}]
					}
				}
			});
		});
	</script>

	<script>
		$(function() {
			// Bar chart
			new Chart(document.getElementById("bar-program"), {
				type: "bar",
				data: {
					labels: [
						<?php
							if(isset($semester)){
								foreach($program as $prog){
									echo "'".$prog['program_name']." in ".$prog['department_id']."', ";
								}
							}
						?>
					],
					datasets: [{
						label: "Enrolled",
						backgroundColor: window.theme.primary,
						borderColor: window.theme.primary,
						hoverBackgroundColor: window.theme.primary,
						hoverBorderColor: window.theme.primary,
						data: [
							<?php
								if(isset($semester)){
									foreach($program as $prog){
										echo "".$prog['students'].", ";
									}
								}
							?>
						],
						barPercentage: .80,
						categoryPercentage: .5
					}]
				},
				options: {
					maintainAspectRatio: false,
					legend: {
						display: false
					},
					scales: {
						yAxes: [{
							gridLines: {
								display: false
							},
							stacked: false,
							ticks: {
								stepSize: 10
							}
						}],
						xAxes: [{
							stacked: false,
							gridLines: {
								color: "transparent"
							}
						}]
					}
				}
			});
		});
	</script>


</body>

</html>